package ComissionElectorale;

import java.util.Scanner;

import Candidat.CandidatAgent;

import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;

public class CommissionContainer {

	/**
	 * @param args
	 */
	//creation du premier container Agent1
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Runtime runtime=Runtime.instance();
		ProfileImpl profileImpl=new ProfileImpl(false);
		profileImpl.setParameter(profileImpl.MAIN_HOST, "localhost");
		AgentContainer agentContainer=runtime.createAgentContainer(profileImpl);
		try {
			//ici nous deployons l'agent CandidatAgent dans le containerAgent
			AgentController agentController=agentContainer.createNewAgent
					("Commission",CommissionAgent.class.getName() ,new Object []{}); //pour envoyer des arguments
			
			agentController.start();
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}