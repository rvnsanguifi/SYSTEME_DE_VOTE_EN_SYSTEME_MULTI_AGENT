package ComissionElectorale;

import java.util.ArrayList;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.ParallelBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;

public class CommissionAgent extends Agent{
	private AID[] listeCandidat;
	private ArrayList<String> liste = null;
	private int nbCandidat = 0;
	private int nbVotant = 0;
	private int nbVoteC1 = 0;
	private int nbVoteC2 = 0;
	private String nom = "";
	/**
	 * @param args
	 */
	
	@Override
	protected void setup() {
		System.out.println("Demarrage de l'Agent Commission");
		ParallelBehaviour pb = new ParallelBehaviour();
		addBehaviour(pb);
		
		//ici l'action s'effectue une seule foi
		pb.addSubBehaviour(new OneShotBehaviour() {	
			@Override
			public void action() {
				DFAgentDescription dfadCanditature = new DFAgentDescription();
				ServiceDescription sdCanditature = new ServiceDescription();
				sdCanditature.setType("Candidature");
				dfadCanditature.addServices(sdCanditature);
				
				try {
					DFAgentDescription[] dfadSearchCanditature = DFService.search(myAgent, dfadCanditature);
					listeCandidat = new AID[dfadSearchCanditature.length];
					for(int i = 0 ; i < dfadSearchCanditature.length ; i++){
						listeCandidat[i] = dfadSearchCanditature[i].getName();
						System.out.println("Liste:" + i + dfadSearchCanditature[i].getName().getLocalName());
						nom = nom + dfadSearchCanditature[i].getName().getLocalName() + "/t";
						nbCandidat = nbCandidat + 1;
					}
					
				} catch (FIPAException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}); 
	//pour faire le calcul de vote et donner le resultat pour une duree donnee
		pb.addSubBehaviour(new TickerBehaviour(this, 100000) {
			
			@Override
			protected void onTick() {
				// TODO Auto-generated method stub
				if (nbVoteC1 > nbVoteC2){
					ACLMessage msgListeCandidat = new ACLMessage(ACLMessage.INFORM);
					msgListeCandidat.setContent("c1 gagnant nb vote" + nbVoteC1 + " sur " + (nbVoteC1 + nbVoteC2));
					msgListeCandidat.addReceiver(new AID("c1", AID.ISLOCALNAME));
					send(msgListeCandidat);
				}
				if (nbVoteC2 > nbVoteC1){
					ACLMessage msgListeCandidat = new ACLMessage(ACLMessage.INFORM);
					msgListeCandidat.setContent("c2 gagnant nb vote" + nbVoteC2 + " sur " + (nbVoteC1 + nbVoteC2));
					msgListeCandidat.addReceiver(new AID("c2", AID.ISLOCALNAME));
					send(msgListeCandidat);
				}
			}
		});
		//l'action s'effectue sans fin
		pb.addSubBehaviour(new CyclicBehaviour() {
			@Override
			public void action() {
				ACLMessage msg = receive();
				if (msg != null){
					if (msg.getPerformative() == ACLMessage.REQUEST){
						String contentMsg = String.valueOf(nbCandidat);
					
						ACLMessage msgListeCandidat = new ACLMessage(ACLMessage.INFORM);
						msgListeCandidat.setContent(contentMsg);
						msgListeCandidat.addReceiver(msg.getSender());
						send(msgListeCandidat);
					}
					
					if (msg.getPerformative() == ACLMessage.INFORM){
						String contentMsg = msg.getContent();					
						if (contentMsg.equals("c1"))
							nbVoteC1 = nbVoteC1 + 1;
						
						if (contentMsg.equals("c2"))
							nbVoteC2 = nbVoteC2 + 1;
					}
				}
			}
		});
	}
	
	@Override
	protected void takeDown() {
		System.out.println("Destruction Agent Commission");
	}
}
