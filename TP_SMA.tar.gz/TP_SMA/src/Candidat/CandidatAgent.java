package Candidat;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.ParallelBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;

public class CandidatAgent extends Agent{

	//creation de la classe agent candidat...qui sera appelé dans le ContainerCandidat
	@Override
	protected void setup() {
		System.out.println("Demarrage de l'Agent Candidat");
		ParallelBehaviour pb = new ParallelBehaviour();
		addBehaviour(pb);
		pb.addSubBehaviour(new OneShotBehaviour() {
			
			@Override
			public void action() {
				DFAgentDescription dfad = new DFAgentDescription();
				dfad.setName(getAID());
				ServiceDescription sd = new ServiceDescription();
				sd.setType("Candidature");
				sd.setName("Candidature-Election");
				dfad.addServices(sd);
				
				try {
					DFService.register(myAgent, dfad);
					System.out.println("Enregistrement de l'Agent Candidat");
				} catch (FIPAException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		pb.addSubBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				ACLMessage msg = receive();
				if (msg != null){
					String contentMsg = msg.getContent();
					System.out.println("Resultat election:" + contentMsg);
				}
			}
		});
	}
	
	@Override
	protected void takeDown() {
		System.out.println("Destruction Agent Candidat");
	}
	
}

