package Candidat;

import java.util.Scanner;

import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;

public class CandidatContainer {

	/**
	 * @param args
	 */
	//creation du premier container Agent1
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Runtime runtime=Runtime.instance();
		ProfileImpl profileImpl=new ProfileImpl(false);
		profileImpl.setParameter(profileImpl.MAIN_HOST, "localhost");
		AgentContainer agentContainer=runtime.createAgentContainer(profileImpl);
		System.out.println("Entrer Le Nom Du Candidat");
		Scanner sc = new Scanner(System.in);
		String candidat_nom = sc.next();
		
		try {
			//ici nous deployons l'agent CandidatAgent dans le containerAgent
			AgentController agentController=agentContainer.createNewAgent
					(candidat_nom,CandidatAgent.class.getName() ,new Object []{}); //pour envoyer des arguments
			agentController.start();
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}