package votant;

import java.util.Scanner;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.ParallelBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;

public class VotantAgent extends Agent{

	//creation de la classe agent votant...qui sera appelé dans le VotantContainer
	@Override
	protected void setup() {
		System.out.println("Demarrage de l'Agent Votant");
		ParallelBehaviour pb = new ParallelBehaviour();
		addBehaviour(pb);
		pb.addSubBehaviour(new OneShotBehaviour() {
			
			@Override
			public void action() {
				DFAgentDescription dfad = new DFAgentDescription();
				dfad.setName(getAID());
				ServiceDescription sd = new ServiceDescription();
				sd.setType("Electeur");
				sd.setName("Electeur-Candidat");
				dfad.addServices(sd);
				
				try {
					DFService.register(myAgent, dfad);
					System.out.println("Enregistrement de l'Agent Electeur");
				} catch (FIPAException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String contentMsg = "demande Liste candidat";
			
				ACLMessage msgListeCandidat = new ACLMessage(ACLMessage.REQUEST);
				msgListeCandidat.setContent(contentMsg);
				msgListeCandidat.addReceiver(new AID("Commission", AID.ISLOCALNAME));
				send(msgListeCandidat);
			}
		});
		
		pb.addSubBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				ACLMessage msg = receive();
				if (msg != null){
					String contentMsg = msg.getContent();
					System.out.println("Resultat:" + contentMsg);
					
					System.out.println("Choisir un candidat:");
					Scanner sc2 = new Scanner(System.in);
					String candidat_nom = sc2.next();
					//sc.close();
					
					ACLMessage msgListeCandidat = new ACLMessage(ACLMessage.INFORM);
					msgListeCandidat.setContent(candidat_nom);
					msgListeCandidat.addReceiver(new AID("Commission", AID.ISLOCALNAME));
					send(msgListeCandidat);
				}
			}
		});
	}
	
	@Override
	protected void takeDown() {
		System.out.println("Destruction Agent Electeur");
	}
	
}

